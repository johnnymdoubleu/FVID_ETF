import requests
from urllib import request
import pandas as pd
import os
from bs4 import BeautifulSoup as bs
import numpy as np
import timeit



def import_data(name, date, df):
    # name: crawl할 ETF의 이름
    # date: crawl할 날짜. 그 날짜의 종목 기준으로 데이터를 크롤
    # df: 새롭게 만들 DataFrame의 기준이 되는 DataFrame

    temp_num = df[df['name'] == name]['number']
    number = str(int(temp_num))
    if len(number) == 1:
        number = '0' + number
    url_kodex = 'http://www.kodex.com/excel_pdf.do?fId=2ETF{}&gijunYMD='.format(number) + str(date)
    filename = '{}.xls'.format(name)

    os.chdir('/Users/jisujung/Desktop/서울대/개인 공부/인턴_ETF/stock_info')
    request.urlretrieve(url_kodex, filename)
    # 일단 작업하는 폴더에 ETF 데이터(기존에 crawl하던 데이터 형식)를 엑셀로 저장

    data = pd.read_excel(filename)
    data = data.rename(columns={'Unnamed: 1': '종목명', 'Unnamed: 2': 'ISIN', 'Unnamed: 3': '종목코드'})
    # 저장한 excel file의 column이 unnamed로 되어있어서 필요한 column만 이름을 지정해주었습니다.

    data = data[3:].reset_index()
    dataset = data[['종목명', '종목코드']]
    # 필요한 data는 결국 종목명과 매칭되는 종목코드이므로 그 둘만 DataFrame으로 return

    return dataset



def soup_maker(code):
    #html 파일 읽어들이
    url_command = 'https://finance.naver.com/item/main.nhn?code=' + str(code)
    temp_response = requests.get(url_command)
    temp_source = temp_response.text
    temp_soup = bs(temp_source, 'html.parser')


    return temp_soup


def extract(soup):
    # parameter로 주어진 soup을 이용해서 해당 페이지에서 금액과 금액 명(어떠한 데이터인 지)을 return
    tr_soup = soup.find_all('tr')
    filtered_tr = []
    money_list = []
    th_index = []
    for tr in tr_soup:
        th = tr.find_all('th')
        if th == []:
            continue
        else:
            sample = th[0].get('class')
            if sample != None and len(sample) == 2 and 'th_cop_anal' in sample[1]:
                filtered_tr.append(tr)
                th_index.append(th[0].text)

    for tr in filtered_tr[:11]:
        td_list = tr.find_all('td')
        money = []
        for td in td_list[4:]:
            money.append(td.text.strip())
        money_list.append(money)

    th_index = th_index[: -3]
    return money_list, th_index


def df_maker(money_list, th_index):
    # 주어진 금액 리스트와 이름 리스트를 데이터 프레임으로 결합
    column_list = ['kind', '2018.03', '2018.06', '2018.09', '2018.12', '2019.03', '2019.06']
    money_df = pd.DataFrame(columns=column_list)
    for i in range(11):
        temp_list = [th_index[i]] + money_list[i]
        temp_array = np.array(temp_list).reshape(1, 7)
        temp_df = pd.DataFrame(temp_array, columns=column_list)
        money_df = money_df.append(temp_df, ignore_index=True)
    money_df = money_df.set_index('kind')
    return money_df



def run(name, date):
    response = requests.get('http://www.kodex.com/libpdf.do')
    soup = bs(response.content, 'html.parser')

    etf_list = []

    a_soup = soup.find_all('a')
    for a in a_soup:
        if '/product_view.do' in a.get('href'):
            etf_list.append([a.get('href')[-2:], a.text])

    etf_df = pd.DataFrame(np.array(etf_list), columns=['number', 'name'])
    etf_df = etf_df[: 107]

    data = import_data(name, date, etf_df)

    for i in range(10):
        name = data.iloc[i]['종목명']
        code = data.iloc[i]['종목코드']
        path_download = '/Users/jisujung/Desktop/서울대/개인 공부/인턴_ETF/stock_info/' + name + '.xlsx'
        soup = soup_maker(code)
        money_list, temp_idx = extract(soup)
        money_df = df_maker(money_list, temp_idx)
        money_df.to_excel(path_download)


if __name__ == '__main__':
    start = timeit.default_timer()
    run('KODEX 200', '20190705')
    stop = timeit.default_timer()
    print(stop - start)