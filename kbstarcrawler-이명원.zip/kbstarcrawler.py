from urllib import request
import os
import time
import calendar
import datetime
from datetime import date
import tox
from workalendar.asia import SouthKorea


class kodexCrawler:
    def __init__(self, path_download):
        self.path_download = path_download

    def requestOn(self, date):
        url = 'http://www.kbam.co.kr/etf/kor/product/product_pdf_excel.jsp?&input_ym=' + str(date) +'&fundCd=4435'
        filename = 'kbstar_200_' + str(date) + '.xls'
        os.chdir(self.path_download)
        request.urlretrieve(url, filename)

def findDay(date):
    fulldate = datetime.datetime.strptime(date, '%Y %m %d').weekday()
    return (calendar.day_name[fulldate])

datt = []
cal = calendar.Calendar()
dallyuk = SouthKorea()
#유일한 단점은 대체 공휴일을 포함하고 있지 않음.
#대체공휴일들을 개별적으로 찾아 holidays로 추가 시켜야됨.


for year in range(2019, 2020):
    for mon in range(6, 7):
        if len(str(mon)) == 1 :
            month = '0'+str(mon)
        else :
            month = mon
        monthdays = [d for d in cal.itermonthdays(year, mon) if d != 0]
        for day in monthdays:
            if len(str(day)) == 1 :
                day = '0'+str(day)
            k = str(year) + ' ' + str(month) + ' ' + str(day)
            if findDay(k) != "Sunday" and findDay(k) != "Saturday" and dallyuk.is_working_day(date(int(year), int(mon), int(day))):
                fulldate = str(year) + '-' + str(month) + '-' + str(day)
                datt.append(fulldate)

for i in datt:
    print('==> Downloading kbstar ETF PDF, date: ', i)
    a = kodexCrawler('D:\\Documents\\FVID_ETF\\kbstaretf')
    a.requestOn(i)
    time.sleep(2)

print('==> Download completed')
