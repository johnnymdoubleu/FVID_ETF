from urllib import request
import os
import time
import requests
from bs4 import BeautifulSoup
import pandas as pd
from datetime import datetime


#html받아오기
response = requests.get('http://www.kodex.com/libpdf.do')
soup = BeautifulSoup(response.content, 'html.parser')

code_dict = {}

for a in soup.find_all('a'):
    k = [a.text, a.get('href')]
    if '/product_view' in k[1]:
        k[1] = k[1][25:]
        k[0] = k[0].replace(' ', '_')
        code_dict[k[0]] = k[1]
code_dict['KODEX_TRF7030'] = 'C3'


#크롤러

class KODEX_crawler:
    def __init__(self, path_download, date, name):
        self.path_download = path_download
        self.datecode = str(date)[:10]
        self.date = str(date)[:4] + str(date)[5:7] + str(date)[8:10]
        self.name = name
        self.code = code_dict[str(name)]

    def get_download(self):
        url = 'http://www.kodex.com/excel_pdf.do?fId=2ETF' + self.code + '&gijunYMD=' + str(self.date)
        filename = self.name + '_' + str(self.date) + '.xls'
        self.filename = filename
        os.chdir(self.path_download)
        if not os.path.isfile(self.path_download + '\\' + self.filename):
            request.urlretrieve(url, filename)

    def sizecheck(self):
        if os.path.getsize(self.path_download + '\\' + self.filename) <= 50:
            os.remove(self.path_download + '\\' + self.filename)



#작동

def crawling(dt_range, name):
    for i in dt_range:
        a = KODEX_crawler('C:\\Users\\parks\\Desktop\\ETF', i, name=name)
        a.get_download()
        a.sizecheck()
        if os.path.isfile(a.path_download + '\\' + a.filename):
            df.loc[str(i)[:10], name] = 1


#업데이트

def update(name):
    today = datetime.today().strftime('%Y%m%d')
    os.chdir('C:\\Users\\parks\\Desktop\\ETF')

    if os.path.isfile('C:\\Users\\parks\\Desktop\\ETF' + '\\' + name + '_' + today):
        print('최신 파일이 이미 존재합니다')

    else:
        dt_range = pd.date_range(start=lastday, end=today, freq='B')
        crawling(dt_range, name)
        print('업데이트가 완료되었습니다')



#수행


if __name__ == '__main__':
    dt_range = pd.date_range(start='20190620', end='20190630', freq='B')
    lastday = str(dt_range[len(dt_range) - 1])[:4] + str(dt_range[len(dt_range) - 1])[5:7] + str(dt_range[len(dt_range) - 1])[8:10]
    df = pd.DataFrame(columns=[x for x in list(code_dict.keys())])


    t1 = time.time()
    for key in list(code_dict.keys())[:5]:
        crawling(dt_range, key)
    t2 = time.time()

    print('다운로드가 완료되었습니다.')
    print('걸린 시간:', t2 - t1)


    update('KODEX_200')
    t3 = time.time()
    print('걸린 시간:', t3 - t2)


    print(df)