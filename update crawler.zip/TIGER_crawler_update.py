from urllib import request
import os
import pandas as pd
from bs4 import BeautifulSoup
import time
import requests
from datetime import datetime

response = requests.get('https://www.tigeretf.com/front/products/index.do?pageType=2')
soup = BeautifulSoup(response.content, 'html.parser')

code_dict = {}

for li in soup.find_all('li'):
    a = li.find('a')
    name = a.text
    name = name.replace(' ', '_')
    href = str(a.get('href'))[35:47]
    if 'TIGER' in name:
        code_dict[name] = href


class tiger_crawler2:
    def __init__(self, path_download, date, name):
        self.path_download = path_download
        self.date = str(date)[:11].strip()
        self.name = name
        self.code = code_dict[str(name)]

    def get_download(self):
        url = 'https://www.tigeretf.com/front/products/excel/pdfExcel.do?ksdFund=' + str(self.code) + '&wkdate=' + str(self.date)
        self.url = url
        filename = str(self.name) + '_' + str(self.date) + '.xls'
        filename = filename.strip()
        self.filename = filename
        os.chdir(self.path_download)
        if not os.path.isfile(self.path_download + '\\' + self.filename):
            request.urlretrieve(url, filename)

    def sizecheck(self):
        if os.path.getsize(self.path_download + '\\' + self.filename) <= 1200:
            os.remove(self.path_download + '\\' + self.filename)


def crawling(dt_range, name):
    for i in dt_range:
        a = tiger_crawler2('C:\\Users\\parks\\Desktop\\ETF2', i, name=name)
        a.get_download()
        a.sizecheck()
        if os.path.isfile(a.path_download + '\\' + a.filename):
            df.loc[str(i)[:10], name] = 1


def update(name):
    today = datetime.today().strftime('%Y%m%d')
    os.chdir('C:\\Users\\parks\\Desktop\\ETF')

    if os.path.isfile('C:\\Users\\parks\\Desktop\\ETF' + '\\' + name + '_' + today):
        print('최신 파일이 이미 존재합니다')

    else:
        dt_range = pd.date_range(start=lastday, end=today, freq='B')
        crawling(dt_range, name)
        print('업데이트가 완료되었습니다')



if __name__ == '__main__':

    dt_range = pd.date_range(start='20190620', end='20190630', freq='B')
    lastday = str(dt_range[len(dt_range) - 1])[:4] + str(dt_range[len(dt_range) - 1])[5:7] + str(dt_range[len(dt_range) - 1])[8:10]
    df = pd.DataFrame(columns=[x for x in list(code_dict.keys())])



    t1 = time.time()
    for key in list(code_dict.keys())[:5]:
        crawling(dt_range, key)
    t2 = time.time()

    print('다운로드가 완료되었습니다.')
    print('걸린 시간:', t2 - t1)


    update('TIGER_200')
    t3 = time.time()
    print('걸린 시간:', t3 - t2)


    print(df)