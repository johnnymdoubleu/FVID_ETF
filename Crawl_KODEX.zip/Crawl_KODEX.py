from requests import (get)
import pandas
from urllib import request
from bs4 import BeautifulSoup
import os
import time

class Generator :
    def __init__(self, path_download):
        self.path_download = path_download
        self.table = self.gen_dict()

    def gen_dict(self):
        html = get('http://www.kodex.com/main.do')
        soup = BeautifulSoup(html.text, 'html.parser')
        lists = soup.select('#openEtfProduct > div > div > div > div > dl > dd > ul > li > a')
        table = {}
        for i in lists:
            code = str(i).split('=')[2].split('\"')[0]
            name = str(i).split('>')[1].split('<')[0].replace(' ', '_')
            table[name] = code
        return table

    def gen_datelist(self, start, end):
        date_list = [str(x)[:11].replace('-','') for x in pandas.date_range(start, end)]
        return date_list

    def download(self, name, start, end):
        n = 0
        date_list = self.gen_datelist(start, end)
        for date in date_list :
            save_name = os.path.join(self.path_download, f'{name}_{date}.xls')
            if not os.path.isfile(save_name) :
                request.urlretrieve(f'http://www.kodex.com/excel_pdf.do?fId={self.table[name]}&gijunYMD={date}', save_name)
                n += 1
            if n % 10 == 0 :
                time.sleep(1)

if __name__ == '__main__' :
    gen = Generator('C:\\Users\\user\\Desktop\\2019_하계인턴\\ETFs')
    gen.download('KODEX_코스피','20190701', '20190703')