from morningstarClass import Scrapper
import time

print('logging in ======================>')
sr = Scrapper()
print('Gathering ETF codes list from Naver Finance...')
codes = sr.getCode()
print(codes)
print('\n\n')
# codes = ['69500','102110']

for code in codes:
    time.sleep(2)
    print('Reading in code : ' + code + ' ...')
    sr.searchETF(code)
    print('Searching for results of ' + sr.getETFname() + '...')

    time.sleep(3)
    quote = sr.getQuote()
    print('Retrieving information from Quote tab...')
    time.sleep(2)
    performance = sr.getPerformance(code)
    print('Retrieving information from Performance tab...')
    time.sleep(2)
    print('Retrieving information from Risk tab...')
    risk=sr.getRisk(code)
    print('Retrieving information from Portfolio tab...')
    asset=sr.getAssetAllo(code)
    sectors=sr.getSectors(code)

    print('finished retrieval \nprinting results... \n\n')

    print(quote),print('\n'),print(performance),print('\n'),print(risk),print('\n'),print(asset),print('\n'),print(sectors),print('\n\n')
