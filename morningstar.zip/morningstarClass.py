from selenium import webdriver
from selenium.common.exceptions import TimeoutException
from selenium.webdriver.common.keys import Keys
from bs4 import BeautifulSoup as bs
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.common.by import By
import time
import re
import pandas as pd

email = ''
pw = ''
# code = '69500'
# url='https://www.morningstar.com/'


class Scrapper(object):
    def __init__(self):
        self.driver = webdriver.Chrome(executable_path="./chromedriver") #chromedriver.exe가 이 파일과 같은 곳에 있기만 하면됩니다.
        self.wait = WebDriverWait(self.driver, 5)
        self.page_source = ''
        self.login()

    def login(self):
        try:
            self.driver.get("https://www.morningstar.com/sign-in")
            emailAddress = self.wait.until(EC.presence_of_element_located((By.NAME, "userName")))
            passWord = self.driver.find_element_by_name("password")
            emailAddress.send_keys(email)
            passWord.send_keys(pw)
            passWord.send_keys(Keys.RETURN)

        except TimeoutException:
            print("TimeoutException! Username/password field or login button not found on glassdoor.com")
            exit()

    def getCode(self):
        self.driver.get('https://finance.naver.com/sise/etf.nhn')
        time.sleep(3)
        nextTab = self.driver.find_element_by_xpath('//li[@class="tab2 _etf_tab"]')
        nextTab.click()

        time.sleep(2)
        soup = bs(self.driver.page_source,"html.parser")

        table = soup.find('tbody', {'id':'etfItemTable'})

        gicode = list()
        for i in table.find_all("a", href=re.compile("code")):
            code = i.attrs['href'][-6:]
            if code[0] == '0':
                code = code[1:]
            gicode.append(code)

        return gicode

    def dismissButton(self):
        try :
            dismiss = self.driver.find_element_by_xpath('//button[@class="mdc-button mds-button mdc-overlay__button mds-button--secondary mdc-button--secondary-fill mds-button--large"]')
            dismiss.click()
        except Exception:
            pass

    def searchETF(self,code):
        self.driver.get('https://www.morningstar.com/')
        search = self.wait.until(EC.presence_of_element_located((By.XPATH, '//input[@class="mdc-search-field__input mds-search-field__input"]')))
        search.send_keys(code)
        search.send_keys(Keys.RETURN)

        time.sleep(2)
        result = self.driver.find_element_by_xpath('//a[@class="mdc-link mdc-security-module__name mds-link mds-link--no-underline"]')
        result.click()

        time.sleep(3)
        try :
            dismiss = self.driver.find_element_by_xpath('//button[@class="mdc-button mds-button mdc-overlay__button mds-button--secondary mdc-button--secondary-fill mds-button--large"]')
            dismiss.click()
        except Exception:
            pass

        self.page_source = self.driver.page_source
        return self.page_source

    def getETFname(self):
        soup = bs(self.page_source, 'html.parser')
        etf = soup.find('span',{'itemprop': 'name'}).text
        return etf

    def getQuote(self):
        time.sleep(3)
        quote=list()
        soup = bs(self.driver.page_source,"html.parser")
        lee=soup.find_all('li',{'class':'sal-snap-panel'})

        for i in range(12,23):
            name = lee[i].find('div',{'class':'sal-dp-name ng-binding'}).text
            name = str(name).replace('  ', '')
            name = str(name).replace('\n', '')
            value = lee[i].find('div',{'class':'sal-dp-value ng-binding'}).text
            value = str(value).replace(' - ', '')
            value = str(value).replace('  ', '')
            value = str(value).replace('\n', '')
            quote.append({name : value})
        return quote

    def getPerformance(self,code):
        performanceChart = self.wait.until(EC.presence_of_element_located((By.XPATH, '//a[@href="/etfs/xkrx/' + code + '/performance"]')))
        # performanceChart = self.driver.find_element_by_xpath('//a[@href="/etfs/xkrx/' + code + '/performance"]')
        performanceChart.click()

        time.sleep(2)
        soup = bs(self.driver.page_source,"html.parser")
        div = soup.find('table',{'class','total-table'})

        smalllist = []
        listOfLists = [[] for i in range(6)]
        iter = 0

        for i in div.find_all('tr',{'class','ng-scope'}) :
            for j in i.find_all('span',{'class','ng-binding ng-scope'}):
                value = j.text
                smalllist.append(value)
            if len(smalllist) == 0 :
                smalllist = []
            else :
                listOfLists[iter] = smalllist
                smalllist = []
                iter += 1

        df = pd.DataFrame(listOfLists,columns=['2009','2010','2011','2012','2013','2014','2015','2016','2017','2018','YTD'],
                index=['Fund (Price)','Fund (NAV)','+/ Category (NAV)', '+/- Index (Price)','Percentile Rank','# of Funds in Category'])
        return df

    def getRisk(self,code):
        time.sleep(2)
        risk = self.wait.until(EC.presence_of_element_located((By.XPATH, '//a[@href="/etfs/xkrx/' + code + '/risk"]')))
        # risk = self.driver.find_element_by_xpath('//a[@href="/etfs/xkrx/' + code + '/risk"]')
        risk.click()

        time.sleep(2)

        soup = bs(self.driver.page_source,'html.parser')
        div = soup.find('div',{'class':'sal-risk-volatility-measures__dataTable'})

        smalllist = []
        listOfLists = [[] for i in range(5)]
        iter = 0

        for i in div.find_all('tr',{'class','ng-scope'}) :
            for j in i.find_all('span',{'class','ng-binding'}):
                value = j.text
                smalllist.append(value)
            if len(smalllist) == 0 :
                smalllist = []
            else :
                listOfLists[iter] = smalllist
                smalllist = []
                iter += 1

        df = pd.DataFrame(listOfLists,columns=['Trailing','Fund','Category','Index'])
        df = df.set_index('Trailing')
        return(df)

    def getAssetAllo(self,code):
        time.sleep(2)
        portfolio = self.wait.until(EC.presence_of_element_located((By.XPATH, '//a[@href="/etfs/xkrx/' + code + '/portfolio"]')))
        # portfolio = self.driver.find_element_by_xpath('//a[@href="/etfs/xkrx/' + code + '/portfolio"]')
        portfolio.click()

        time.sleep(2)

        soup = bs(self.driver.page_source,'html.parser')

        div = soup.find('div',{'class':'sal-columns sal-small-12 sal-asset-allocation__assetTable sal-medium-8'})

        smalllist = []
        listOfLists = [[] for i in range(6)]
        iter = 0

        for i in div.find_all('tr',{'class','ng-scope'}) :
            for j in i.find_all('td',{'class','ng-binding ng-scope'}):
                value = j.text
                value = str(value).replace('\n', '')
                value = str(value).replace('  ', '')
                smalllist.append(value)

            listOfLists[iter] = smalllist
            smalllist = []
            iter += 1

        df = pd.DataFrame(listOfLists,columns=['Net','Short','Long','Category', 'Index'],
                index=['US Stock','Non-US Stock','Bonds','Other','Cash','Not Classified'])
        return df

    def getSectors(self,code):
            portfolio = self.driver.find_element_by_xpath('//a[@href="/etfs/xkrx/' + code + '/portfolio"]')
            portfolio.click()

            time.sleep(2)

            soup = bs(self.driver.page_source,'html.parser')

            div = soup.find('div',{'class':'sal-sector-exposure__sector-table-wrapper'})

            smalllist = []
            listOfLists = [[] for i in range(11)]
            iter = 0

            for i in div.find_all('tr',{'class','ng-scope'}) :
                for j in i.find_all('span',{'class','ng-binding'}):
                    value = j.text
                    value = str(value).replace('\n', '')
                    value = str(value).replace('  ', '')
                    smalllist.append(value)

                listOfLists[iter] = smalllist
                smalllist = []
                iter += 1

            # time.sleep(2)
            # portfolio = self.driver.find_element_by_xpath('//a[@href="/etfs/xkrx/69500/portfolio"]')
            # portfolio.send_keys(Keys.PAGE_DOWN)
            # portfolio.send_keys(Keys.PAGE_DOWN)
            # time.sleep(1)
            # button = self.driver.find_element_by_xpath('//button[@class="sal-drop-down-button-dropbtn"]')
            # button.click()
            # time.sleep(1)
            #
            # button = self.driver.find_element_by_xpath('//a[@class="ng-binding ng-scope"]')
            # button.click()
            #
            # time.sleep(3)
            #
            # iter =0
            # for i in div.find_all('tr',{'class','ng-scope'}) :
            #     td = i.find('td',{'ng-if','vm.compareView === vm.compareViews.index'})
            #     print(td)
            #     value = td.find('span',{'class','ng-binding'}).text
            #     value = str(value).replace('\n', '')
            #     value = str(value).replace('  ', '')
            #     listOfLists[iter].append(value)
            #     iter += 1
            #
            # print(listOfLists)

            df = pd.DataFrame(listOfLists,columns=['Sectors', 'Fund %','Category %'])
            df = df.set_index('Sectors')
            return(df)



# driver = webdriver.Chrome(executable_path="./chromedriver")
#
# portfolio = driver.find_element_by_xpath('//a[@href="/etfs/xkrx/69500/portfolio"]')
# portfolio.click()
#
# driver.get('https://www.morningstar.com/etfs/xkrx/69500/portfolio')
#
# time.sleep(2)
#
# soup = bs(driver.page_source,'html.parser')
#
# div = soup.find('div',{'class':'sal-sector-exposure__sector-table-wrapper'})
#
# smalllist = []
# listOfLists = [[] for i in range(11)]
# iter = 0
#
# for i in div.find_all('tr',{'class','ng-scope'}) :
#     for j in i.find_all('span',{'class','ng-binding'}):
#         value = j.text
#         value = str(value).replace('\n', '')
#         value = str(value).replace('  ', '')
#         smalllist.append(value)
#
#     listOfLists[iter] = smalllist
#     smalllist = []
#     iter += 1
# # time.sleep(2)
# # portfolio = driver.find_element_by_xpath('//a[@href="/etfs/xkrx/69500/portfolio"]')
# # portfolio.send_keys(Keys.PAGE_DOWN)
# # portfolio.send_keys(Keys.PAGE_DOWN)
# # time.sleep(1)
# # button = driver.find_element_by_xpath('//button[@class="sal-drop-down-button-dropbtn"]')
# # button.click()
# # time.sleep(1)
# #
# # button = driver.find_element_by_xpath('//a[@class="ng-binding ng-scope"]')
# # button.click()
# #
# # time.sleep(3)
# #
# # iter =0
# # for i in div.find_all('tr',{'class','ng-scope'}) :
# #     td = i.find('td',{'ng-if','vm.compareView === vm.compareViews.index'})
# #     print(td)
# #     value = td.find('span',{'class','ng-binding'}).text
# #     value = str(value).replace('\n', '')
# #     value = str(value).replace('  ', '')
# #     listOfLists[iter].append(value)
# #     iter += 1
# #
# # print(listOfLists)
# df = pd.DataFrame(listOfLists,columns=['Sectors', 'Fund %','Category %'])
# df = df.set_index('Sectors')
# print(df)



#
# risk = self.driver.find_element_by_xpath('//a[@href="/etfs/xkrx/69500/risk"]')
# risk.click()
# driver.get('https://www.morningstar.com/etfs/xkrx/69500/risk')
#
# time.sleep(2)
#
# soup = bs(driver.page_source,'html.parser')
# div = soup.find('div',{'class':'sal-risk-volatility-measures__dataTable'})
#
# smalllist = []
# listOfLists = [[] for i in range(5)]
# iter = 0
#
# for i in div.find_all('tr',{'class','ng-scope'}) :
#     for j in i.find_all('span',{'class','ng-binding'}):
#         value = j.text
#         smalllist.append(value)
#     if len(smalllist) == 0 :
#         smalllist = []
#     else :
#         listOfLists[iter] = smalllist
#         smalllist = []
#         iter += 1
#
# print(listOfLists)
#
# df = pd.DataFrame(listOfLists,columns=['Trailing','Fund','Category','Index'])
# df = df.set_index('Trailing')
# print(df)


# wait = WebDriverWait(driver, 5)
#
# driver.get('https://www.morningstar.com/sign-in')
# time.sleep(2)
# emailAddress = driver.find_element_by_name('userName')
# passWord = driver.find_element_by_name('password')
#
# emailAddress.send_keys(email)
# passWord.send_keys(pw)
# passWord.send_keys(Keys.RETURN)
#
# search = wait.until(EC.presence_of_element_located((By.XPATH, '//input[@class="mdc-search-field__input mds-search-field__input"]')))
#
# search.send_keys(code)
# search.send_keys(Keys.RETURN)
#
# time.sleep(2)
#
# result = driver.find_element_by_xpath('//a[@class="mdc-link mdc-security-module__name mds-link mds-link--no-underline"]')
# result.click()
#
# time.sleep(1)
#
# dismiss = driver.find_element_by_xpath('//button[@class="mdc-button mds-button mdc-overlay__button mds-button--secondary mdc-button--secondary-fill mds-button--large"]')
# dismiss.click()
#
# time.sleep(2)

# quote=list()
#
# driver.get('https://www.morningstar.com/etfs/xkrx/69500/quote')
#
# time.sleep(3)
# soup = bs(driver.page_source,"html.parser")
# lee=soup.find_all('li',{'class':'sal-snap-panel'})
# # print(lee[12])
#
# # print(lee[12].find('div',{'class':'sal-dp-name ng-binding'}).text)
#
# for i in range(12,23):
#     name = lee[i].find('div',{'class':'sal-dp-name ng-binding'}).text
#     name = str(name).replace('  ', '')
#     name = str(name).replace('\n', '')
#     value = lee[i].find('div',{'class':'sal-dp-value ng-binding'}).text
#     value = str(value).replace('  ', '')
#     value = str(value).replace('\n', '')
#     quote.append({name : value})
#     # quote.append(value)
#

# performanceChart = driver.find_element_by_xpath('//a[@href="/etfs/xkrx/69500/performance"]')
# performanceChart.click()
# dismiss = driver.find_element_by_xpath('//button[@class="mdc-button mds-button mdc-overlay__button mds-button--secondary mdc-button--secondary-fill mds-button--large"]')
# dismiss.click()

# driver.get('https://www.morningstar.com/etfs/xkrx/69500/performance')
#
# time.sleep(3)
# soup = bs(driver.page_source,"html.parser")
# div = soup.find('table',{'class','total-table'})
#
# smalllist = []
# listOfLists = [[] for i in range(6)]
# iter = 0
#
# for i in div.find_all('tr',{'class','ng-scope'}) :
#     for j in i.find_all('span',{'class','ng-binding ng-scope'}):
#         value = j.text
#         smalllist.append(value)
#     if len(smalllist) == 0 :
#         smalllist = []
#     else :
#         listOfLists[iter] = smalllist
#         smalllist = []
#         iter += 1
#
# df = pd.DataFrame(listOfLists,columns=['2009','2010','2011','2012','2013','2014','2015','2016','2017','2018','YTD'],
#         index=['Fund (Price)','Fund (NAV)','+/ Category (NAV)', '+/- Index (Price)','Percentile Rank','# of Funds in Category'])
#
# print(df)
