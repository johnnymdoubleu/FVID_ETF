import requests
from bs4 import BeautifulSoup
import numpy as np
import pandas as pd
import os
from urllib import request

response = requests.get('http://www.kodex.com/libpdf.do')
soup = BeautifulSoup(response.content, 'html.parser')

code_list = []

a_soup = soup.find_all('a')
for a in a_soup:
    if '/product_view.do' in a.get('href'):
        code_list.append([a.get('href')[-2:], a.text])

code_df = pd.DataFrame(np.array(code_list), columns=['number', 'name'])
code_df = code_df[: 107]


class Kodex_Crawler:
    def __init__(self, path_download, name, file_df):
        self.path_download = path_download
        self.name = name
        sample = code_df[code_df['name'] == self.name]['number']
        self.number = str(int(sample))
        if len(self.number) == 1:
            self.number = '0' + self.number
        self.file_df = file_df

    def download(self, date):
        url = "https://www.kodex.com/excel_pdf.do?fId=2ETF{}&gijunYMD=".format(self.number) + str(date)
        os.chdir(self.path_download)
        filename = '{}_'.format(self.name) + str(date) + '.xls'
        mem = request.urlopen(url)
        size = int(mem.info()['Content-Length'])
        if size != 0:
            temp_df = pd.DataFrame({'date': [date], 'file_name': [filename]})
            self.file_df = self.file_df.append(temp_df, ignore_index=True)
            with open(filename, mode='wb') as f:
                f.write(mem.read())
        return self.file_df



winter2019 = pd.date_range(start='20190101', end='20190228', freq='B')
spring2019 = pd.date_range(start='20190301', end='20190531', freq='B')
summer2019 = pd.date_range(start='20190601', end='20190701', freq='B')

file_df = pd.DataFrame(columns=['date', 'file_name'])

if __name__ == '__main__':
    tester = Kodex_Crawler('/Users/jisujung/Desktop/서울대/개인 공부/인턴_ETF/kodex_crawled', 'KODEX 200', file_df)

    for day in summer2019:
        date = str(day)[: 4] + str(day)[5: 7] + str(day)[8: 10]
        tester.download(date)
    print(tester.file_df)
    tester.file_df.to_excel('/Users/jisujung/Desktop/서울대/개인 공부/인턴_ETF/kodex_crawled/downloaded.xlsx')


